# Vishwa Portfolio Website

## How to Publish

### Option 1: GitHub Pages (Free)
1. Create a GitHub account at github.com
2. Create a new repository named `vishwa-portfolio`
3. Upload all files from this folder
4. Go to Settings → Pages → Select "main" branch
5. Your site will be live at: `https://yourusername.github.io/vishwa-portfolio`

### Option 2: Netlify (Free)
1. Go to netlify.com and sign up
2. Drag and drop this entire folder onto the Netlify dashboard
3. Your site goes live instantly with a free URL

### Option 3: Vercel (Free)
1. Go to vercel.com and sign up
2. Import your GitHub repository
3. Deploy with one click

### Option 4: Traditional Web Hosting
1. Buy hosting from any provider (Hostinger, Bluehost, etc.)
2. Upload all files via FTP or File Manager
3. Your site is live at your domain

## Files Included
- `index.html` - Main portfolio page
- `images/vishwa-photo.jpg` - Your profile photo
- `css/` - Stylesheets (if separated later)
- `js/` - JavaScript files (if separated later)

## Contact Info
- Name: Vishwa
- Phone: +91 6379588003
- Email: vishwa7960202@gmail.com
- Location: Salem, Tamil Nadu, India
- LinkedIn: linkedin.com/in/vishwa
